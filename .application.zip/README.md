# Language School [![Build Status](https://travis-ci.org/dark-side/language-school.svg)](https://travis-ci.org/profile/dark-side) [![Code Climate](https://codeclimate.com/github/dark-side/language-school/badges/gpa.svg)](https://codeclimate.com/github/dark-side/language-school) [![Test Coverage](https://codeclimate.com/github/dark-side/language-school/badges/coverage.svg)](https://codeclimate.com/github/dark-side/language-school/coverage)
The d360 application which allows to manage the school activities.

