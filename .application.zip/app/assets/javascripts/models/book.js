Bb.Models.Book = Backbone.Model.extend({
	urlRoot: '/api/v1/books'
});
