Bb.Models.Comment = Backbone.Model.extend({});
