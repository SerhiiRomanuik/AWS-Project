Bb.Models.Article = Backbone.Model.extend({
  urlRoot: "/api/v1/articles"
});
