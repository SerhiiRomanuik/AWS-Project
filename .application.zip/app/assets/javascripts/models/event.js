Bb.Models.Event = Backbone.Model.extend({
  urlRoot: '/api/v1/events'
});
