Bb.Models.Picture = Backbone.Model.extend({
	urlRoot: '/api/v1/pictures'
});
