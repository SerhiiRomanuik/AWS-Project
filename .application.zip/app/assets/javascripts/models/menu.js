Bb.Models.Menu = Backbone.Model.extend({
 urlRoot: "/api/v1/menus"
});
