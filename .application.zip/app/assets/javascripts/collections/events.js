Bb.Collections.Events = Backbone.Collection.extend({

  url: '/api/v1/events',
  model: Bb.Models.Event

});
