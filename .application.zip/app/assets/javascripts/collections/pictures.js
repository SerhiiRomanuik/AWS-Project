Bb.Collections.Pictures = Backbone.Collection.extend({
  url: '/api/v1/pictures',
  model: Bb.Models.Picture
});
