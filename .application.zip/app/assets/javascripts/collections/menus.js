Bb.Collections.Menus = Backbone.Collection.extend({

 url: "/api/v1/menus",
 model: Bb.Models.Menu
 });
