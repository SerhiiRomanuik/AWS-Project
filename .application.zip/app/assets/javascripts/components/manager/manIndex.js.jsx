var ManIndex = React.createClass({
  render: function() {
    return (
      <div className="row">
        <div className="col-xs-12">
          <h1>Welcome</h1>
          <h2>Language school administration panel</h2>
        </div>
      </div>
    );
  }
});
