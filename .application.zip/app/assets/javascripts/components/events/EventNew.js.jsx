var EventNew = React.createClass({
  render: function () {
    return (
      <EventForm mode="new">
        <h2>Create event</h2>
      </EventForm>
    );
  }
});
