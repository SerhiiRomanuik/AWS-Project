var SignInLink = React.createClass({
  render: function() {
    return (
      <li>
        <a href='#users/sign_in'>Log In <span className="glyphicon glyphicon-log-in"></span></a>
      </li>
    );
  }
});
