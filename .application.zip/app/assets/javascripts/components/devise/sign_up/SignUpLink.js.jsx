var SignUpLink = React.createClass({
  render: function() {
    return (
      <li>
        <a href='#users/sign_up'>Sign Up <span className="glyphicon glyphicon-user"></span></a>
      </li>
    );
  }
});
