var GetCurrentUserId = {
  getCurrentUserId: function() {
    return $("div[data-user-id]").data("userId");
  },
};
