var CheckUserId = {
  checkUserId: function() {
    return this.props.current_user_id == this.props.user_id;
  },
};
