$(function() {
    $('dropdown-toggle').dropdown();
});
