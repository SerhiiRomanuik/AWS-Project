FactoryGirl.define do
  factory :page do
    title 'Title'
    body 'Body'
  end
end
