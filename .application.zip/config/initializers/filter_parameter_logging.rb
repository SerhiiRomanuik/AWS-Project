Rails.application.config.filter_parameters += [:password]
