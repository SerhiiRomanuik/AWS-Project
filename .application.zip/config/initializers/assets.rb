Rails.application.config.assets.version = '1.0'
