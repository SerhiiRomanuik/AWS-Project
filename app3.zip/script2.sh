#!/bin/bash

# find ip_dir || mkdir ip_dir
# string=`terraform plan | grep privat_ip > ip_dir/.file ; awk '//{print $4;}' ip_dir/.file > ip_dir/.file2`
# string1=`sed -n 1p ip_dir/.file2`
# string2=`sed -n 2p ip_dir/.file2`
# echo ${string1:1:-1} > ip_dir/inst_ip
# echo ${string2:1:-1} >> ip_dir/inst_ip

find id_dir || mkdir id_dir
terraform output > id_dir/id_inst
string1=`sed -n '2p' id_dir/id_inst`
string2=`sed -n '3p' id_dir/id_inst`
inst_1=`echo ${string1:3:-2}`                # > id_dir/id_inst
inst_2=`echo ${string2:3:-2}`                # >> id_dir/id_inst


aws autoscaling attach-instances --instance-ids $inst_1 --auto-scaling-group-name ASG-TERRAFORM
aws autoscaling attach-instances --instance-ids $inst_2 --auto-scaling-group-name ASG-TERRAFORM